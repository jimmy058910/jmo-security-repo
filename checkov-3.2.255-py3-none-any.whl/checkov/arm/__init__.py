from checkov.arm.checks import *  # noqa
