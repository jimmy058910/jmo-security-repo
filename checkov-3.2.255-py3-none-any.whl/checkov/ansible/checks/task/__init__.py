from checkov.ansible.checks.task.aws import *  # noqa
from checkov.ansible.checks.task.builtin import *  # noqa
