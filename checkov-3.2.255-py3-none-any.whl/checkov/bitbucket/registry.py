from checkov.common.bridgecrew.check_type import CheckType
from checkov.json_doc.base_registry import Registry

registry = Registry(CheckType.BITBUCKET_CONFIGURATION)
